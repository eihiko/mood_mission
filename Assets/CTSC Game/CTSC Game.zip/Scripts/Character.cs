﻿using UnityEngine;
using System.Collections;

[System.Serializable]
public class Character : MonoBehaviour {
	
	public string name;
	
	public Character(){
		this.name = "";
	}

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
