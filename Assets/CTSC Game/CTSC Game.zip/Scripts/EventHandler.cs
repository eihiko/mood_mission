﻿using System.Collections.Generic;
using UnityEngine;
using System.Collections;

/**
 * Handles game events like transitioning between
 * states of the game and controls.
 * 
 * @author Shaun Howard
 */
public class EventHandler: MonoBehaviour
{
	
	public enum GameState
	{
		START,
		TRANSPORT,
		LOAD,
		SAVE,
		PLAY,
		PAUSE
	}

	public enum GameLocation
	{
		TDC,
		TDDL,
		TDDS,
		TDI,
		F
	}
	
	public static EventHandler current;
	public GameObject saveManagerObject;
	public float loadTime;
	public GameObject player;
	public GameObject playerCamera;
	public GameObject locations;
	CurrentLevel currLevel;
	
	//The set of locations to transport to.
	Dictionary<GameLocation, Transform> locationSet;
	
	PlayerScreenFade playerScreenFade;
	PerfectController controller;
	Character playerChar;
	PauseMenu pauseMenu;
	
	private bool firstLoad = false;
	private GameState currState, lastState;
	private GameLocation currLocation, lastLocation;
	
	// Keeps the manager alive throughout the game
	void Awake()
	{
		DontDestroyOnLoad(transform.gameObject);
	}

	// Use this for initialization
	void Start()
	{
		currLevel = player.GetComponent<CurrentLevel>();
		lastLocation = currLevel.getCurrLocation();
		locationSet = new Dictionary<GameLocation, Transform>();

		//Map all locations to their enum in locations map.
		foreach (Transform location in locations.transform) {
			GameLocation enumLoc = switchLocation(location.gameObject.name);
			locationSet.Add(enumLoc, location);
			Debug.Log(location.gameObject.name);
			if (location.gameObject.activeSelf && firstLoad) {
				currLevel.setCurrLocation(enumLoc);
			}
		}
		
		Screen.showCursor = false;
		Screen.lockCursor = true;
		pauseMenu = saveManagerObject.GetComponent<PauseMenu>();
		playerScreenFade = playerCamera.GetComponent<PlayerScreenFade>();
		controller = player.GetComponent<PerfectController>();
		playerChar = player.GetComponent<Character>();
		currState = GameState.START;
		lastState = GameState.START;
		firstLoad = false;
	}
	
	// Update is called once per frame
	void Update()
	{
		//Determine the currently loaded location.
		currLocation = currLevel.getCurrLocation();
//		if (lastLocation != currLocation) {
			EnableLocation(currLocation);
//			lastLocation = currLocation;
//		}
		
		//Pause/unpause the game.
		if (Input.GetKeyUp(KeyCode.Escape) && currState != GameState.PAUSE) {
			pauseMenu.setPaused(true);
			Time.timeScale = 0;
			currState = GameState.PAUSE;
		} else if (Input.GetKeyUp(KeyCode.Escape) && currState == GameState.PAUSE) {
			pauseMenu.setPaused(false);
			Time.timeScale = 1;
			currState = GameState.PLAY;
		}
		
		controller.UpdatePlayer(currState);
		
//		//Transport the player.
//		if (Input.GetKeyDown("E")) {
//			currState = GameState.TRANSPORT;
//			Debug.Log("Transport key pressed.");
//		}
		
		updateGame(currState);
	}
	
	public void updateGame(GameState state)
	{
		switch (currState) {
			case GameState.START:
				Start();
				lastState = GameState.START;
				break;
			case GameState.LOAD:
				Load();
				lastState = GameState.LOAD;
				break;
			case GameState.TRANSPORT:
				Transport();
				lastState = GameState.TRANSPORT;
				break;
			case GameState.PLAY:
				Play();
				lastState = GameState.PLAY;
				break;
			case GameState.PAUSE:
				Pause();
				lastState = GameState.PAUSE;
				break;
		}
	}

	public void EnableLocation(GameLocation currLocation)
	{
		GameObject currLocationObj;
		foreach (KeyValuePair<GameLocation, Transform> kvp in locationSet) {
			currLocationObj = kvp.Value.gameObject;
			
			if (kvp.Key == currLocation) {
				currLevel.setCurrLocation(currLocation);
				currLocationObj.SetActive(true);
			} else {
				currLocationObj.SetActive(false);
			}
		}
	}
	
	/**
	 * Handles load tasks in the game.
	 */
	void Load()
	{

	}
	
	/**
	 * Handles the transport of the player.
	 */
	void Transport()
	{
		//Fades the screen out and back in.
		StartCoroutine("Fade");
	}
	
	/**
	 * Fades the player camera to black, waits 
	 * for the given load time, and fades back
	 * to play.
	 */
	IEnumerator Fade()
	{
		playerScreenFade.Fade(false, .001f);
		yield return new WaitForSeconds(loadTime);
		playerScreenFade.Fade(true, .001f);
		Debug.Log("in fade coroutine");
		DestroyObject(GameObject.Find("Screen Fade"));
		yield return null;
	}
	
	/**
	 * Handles play tasks in the game.
	 */
	void Play()
	{
	}
	
	/**
	 * Handles pause tasks in the game.
	 */
	void Pause()
	{
	}
	
	/**
	 * Loads the scene with the specified name.
	 * @param scene - the scene name to load
	 */
	void LoadScene(string scene)
	{
		Application.LoadLevel(scene);
	}
	
	/**
	 * Sets the state of the game.
	 * 
	 * @param state - the state to put the game in
	 */
	public void setGameState(GameState state)
	{
		currState = state;
	}
	
	public void rotatePlayer(Vector3 angle)
	{
		playerCamera.transform.localRotation.Set(angle.x, angle.y, angle.z, playerCamera.transform.rotation.w);
	}
	
	public void reinstantiatePlayer(Vector3 position, Quaternion rotation)
	{
		Instantiate(player, position, rotation);
	}
	
	/**
	 * Gets the enum of the location given.
	 * Returns TDC by default.
	 * @param location - the location to get the enum of
	 * @return the enum of the given location
	 */
	public GameLocation switchLocation(string location)
	{
		switch (location) {
			case "TopDownCity":
				return EventHandler.GameLocation.TDC;
			case "TopDownDungeonLarge":
				return EventHandler.GameLocation.TDDL;
			case "TopDownDungeonSmall":
				return EventHandler.GameLocation.TDDS;
			case "TopDownInteriors":
				return EventHandler.GameLocation.TDI;
			case "Forest":
				return EventHandler.GameLocation.F;
		}
		return EventHandler.GameLocation.TDC;
	}
}
