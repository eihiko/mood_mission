﻿using System.Collections.Generic;
using UnityEngine;

public class PauseMenu : MonoBehaviour{
	
	public GUITexture pausedGUI;
	public string gameName = "Your Game";
	public List<Transform> myList = new List<Transform>();
	bool paused = false;

	void Start() {
		if (pausedGUI)
			pausedGUI.enabled = false;
	}

	void Update() { 
		if (paused) { 
			//pause the game
			if (pausedGUI)
				pausedGUI.enabled = true;
		} else {
			//unpause the game
			if (pausedGUI)
				pausedGUI.enabled = false;
		}
	}

	void OnGUI() {
		if (!paused) {
			GUILayout.BeginArea(new Rect(200, 10, 400, 20));
			GUILayout.BeginVertical();
			GUILayout.BeginHorizontal();
			GUILayout.FlexibleSpace();
			GUILayout.Label("Press Escape to Pause");
			GUILayout.FlexibleSpace();
			GUILayout.EndHorizontal();
			GUILayout.EndVertical();
			GUILayout.EndArea();
			return;
		}
	   
		GUIStyle box = "box";   
		GUILayout.BeginArea(new Rect(Screen.width / 2 - 200, Screen.height / 2 - 300, 400, 600), box);

		GUILayout.BeginVertical(); 
		GUILayout.FlexibleSpace();
		if (GUILayout.Button("Save Game")) {
			LevelSerializer.SaveGame(gameName);
		}
		GUILayout.Space(60);
		foreach (LevelSerializer.SaveEntry sg in LevelSerializer.SavedGames[LevelSerializer.PlayerName]) { 
			if (GUILayout.Button(sg.Caption)) { 
				LevelSerializer.LoadNow(sg.Data);
				Time.timeScale = 1;
			} 
		} 
		GUILayout.FlexibleSpace();
		GUILayout.EndVertical();
		GUILayout.EndArea();
	}
	
	public void setPaused(bool paused) {
		this.paused = paused;
	}
}
