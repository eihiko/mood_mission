﻿using UnityEngine;
using System;
using System.Collections.Generic;

/**
 * Tranportation Manager. 
 * When the given collider is hit, the player will
 * transport to the given scene location input as
 * a string of the name of the location in the scene.
 * 
 * Input must have an "Transport" axis, with the default value
 * being "e" to transport the player.
 * 
 * @author Shaun Howard
 */
[System.Serializable]
public class TransportPlayer : MonoBehaviour {
	
	public String location;
	public Transform playerStart;
	public float yawOnStart;
	
	Vector3 currPlayerPosition;
	Quaternion currPlayerRotation;
	GameObject player, locations;
	EventHandler eventHandler;
	Vector3 targetPostition;

	// Use this for initialization
	void Start () {
		eventHandler = GameObject.Find("EventHandler").GetComponent<EventHandler>();
		currPlayerPosition = new Vector3 ();
		currPlayerRotation = new Quaternion ();
	}
	
	// Update is called once per frame
	void FixedUpdate () {

	}

	void OnTriggerStay(Collider col){
		Debug.Log("Entered trigger");
		if(col.gameObject.tag.Equals("Player") && Input.GetKeyDown(KeyCode.E)){
			//Handles fade out.
			eventHandler.setGameState(EventHandler.GameState.TRANSPORT);
			Debug.Log("Into transport area");
			player = col.gameObject;

			//Store the current player position.
			currPlayerPosition = player.transform.position;
			currPlayerRotation = player.transform.rotation;

			//Plays the door animation.
			//transform.FindChild("door").SendMessage("DoorCheck"); 

			//Transports player to given location.
			Transport();
			
			//Rotates the player to the given rotation.
			Rotate();
		}
	}

	/**
	 * Transports the player to the location set 
	 * in the inspector for this door.
	 * Will disable the other locations and 
	 * enable the desired location of transport.
	 */
	void Transport(){
		EnableTransportLocation ();
		Vector3 transportLocation = playerStart.transform.position;
	    player.transform.position = transportLocation;
    }
	
	/**
	 * Rotates the player to the rotation set in the inspector.
	 */
	void Rotate(){
		 player.GetComponent<PerfectController>().yaw = yawOnStart;
	}

	/**
	 * Enables the given transport location
	 * and disables the others in the game.
	 * Also sets the current level for the save game manager
	 * to load on a given save.
	 */
	void EnableTransportLocation(){
		eventHandler.EnableLocation(eventHandler.switchLocation(location));
    }
}
