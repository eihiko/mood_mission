﻿using UnityEngine;

public abstract class Togglable : MonoBehaviour {
	public abstract void toggle();
}
